from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.db import transaction
from .models import CustomUser, Patient, Doctor

class UserTypeForm(forms.Form):
    USER_CHOICES = [
        ('patient', 'Patient'),
        ('doctor', 'Doctor'),
    ]
    user_type = forms.ChoiceField(choices=USER_CHOICES, widget=forms.RadioSelect)

class PatientSignupForm(UserCreationForm):
    email = forms.EmailField(required=True)
    username = forms.CharField(max_length=30, required=True)  
    password1 = forms.CharField(widget=forms.PasswordInput)  
    password2 = forms.CharField(widget=forms.PasswordInput)
    
    first_name = forms.CharField(max_length=30, required=True)
    last_name = forms.CharField(max_length=30, required=True)
    profile_picture = forms.ImageField(required=False)
    address_line1 = forms.CharField(max_length=255, required=True)
    city = forms.CharField(max_length=100, required=True)
    state = forms.CharField(max_length=100, required=True)
    pincode = forms.CharField(max_length=10, required=True)

    class Meta(UserCreationForm.Meta):
        model = CustomUser
        fields = ['username', 'email', 'password1', 'password2']

    @transaction.atomic
    def save(self):
        user = super().save(commit=False)
        user.is_patient = True
        user.is_active = True
        user.save()
        patient = Patient.objects.create(user=user)
        patient.email = self.cleaned_data.get('email')
        patient.first_name = self.cleaned_data.get('first_name')
        patient.last_name = self.cleaned_data.get('last_name')
        patient.profile_picture = self.cleaned_data.get('profile_picture')
        patient.address_line1 = self.cleaned_data.get('address_line1')
        patient.city = self.cleaned_data.get('city')
        patient.state = self.cleaned_data.get('state')
        patient.pincode = self.cleaned_data.get('pincode')
        patient.save()
        return user
    
class DoctorSignupForm(UserCreationForm):
    email = forms.EmailField(required=True)
    username = forms.CharField(max_length=30, required=True)
    password1 = forms.CharField(widget=forms.PasswordInput)  
    password2 = forms.CharField(widget=forms.PasswordInput)  


    
    first_name = forms.CharField(max_length=30, required=True)
    last_name = forms.CharField(max_length=30, required=True)
    profile_picture = forms.ImageField(required=False)
    address_line1 = forms.CharField(max_length=255, required=True)
    city = forms.CharField(max_length=100, required=True)
    state = forms.CharField(max_length=100, required=True)
    pincode = forms.CharField(max_length=10, required=True)

    class Meta(UserCreationForm.Meta):
        model = CustomUser
        fields = ['username', 'email', 'password1', 'password2'] 

    @transaction.atomic
    def save(self):
        user = super().save(commit=False)
        user.is_doctor = True
        user.is_active = True
        user.save()
        doctor = Doctor.objects.create(user=user)
        doctor.email = self.cleaned_data.get('email')
        doctor.first_name = self.cleaned_data.get('first_name')
        doctor.last_name = self.cleaned_data.get('last_name')
        doctor.profile_picture = self.cleaned_data.get('profile_picture')
        doctor.address_line1 = self.cleaned_data.get('address_line1')
        doctor.city = self.cleaned_data.get('city')
        doctor.state = self.cleaned_data.get('state')
        doctor.pincode = self.cleaned_data.get('pincode')
        doctor.save()
        return user
