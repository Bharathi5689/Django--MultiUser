
from django.urls import reverse_lazy
from django.contrib.auth.views import LoginView
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth import login as auth_login
from django.contrib import messages
from .forms import UserTypeForm, PatientSignupForm, DoctorSignupForm
from .models import Patient, Doctor

@login_required
def dashboard_redirect(request):
    user = request.user
    if user.is_authenticated and hasattr(user, 'patient'):
        return redirect('patient_dashboard')  # Redirect to patient dashboard
    elif user.is_authenticated and hasattr(user, 'doctor'):
        return redirect('doctor_dashboard')  # Redirect to doctor dashboard
    else:
        return redirect('home') 

class MyLoginView(LoginView):
    template_name = 'login.html'

    def get_success_url(self):
        return reverse_lazy('dashboard_redirect')
    
@login_required
def patient_dashboard(request):
    user = request.user
    patient = Patient.objects.get(user=user)

    display_fields = {
        'First Name': patient.user.first_name,
        'Last Name': patient.user.last_name,
        'Email': patient.user.email,
        'Username':user.username,
        
    }
    return render(request, 'patient_dashboard.html', {'patient':patient})

@login_required
def doctor_dashboard(request):
    user = request.user
    doctor = Doctor.objects.get(user=user)

    display_fields = {
        'First Name': doctor.user.first_name,
        'Last Name': doctor.user.last_name,
        'Email': doctor.user.email,
        'Username': user.username,
        'Specialization': doctor.specialization,
        }
    return render(request, 'doctor_dashboard.html', {'doctor':doctor})

def signup(request):
    if request.method == 'POST':
        user_type_form = UserTypeForm(request.POST)
        if user_type_form.is_valid():
            user_type = user_type_form.cleaned_data['user_type']
            if user_type == 'patient':
                return redirect('patient_signup')
            elif user_type == 'doctor':
                return redirect('doctor_signup')
    else:
        user_type_form = UserTypeForm()

    return render(request, 'signup.html', {'user_type_form': user_type_form})

def patient_signup(request):
    if request.method == 'POST':
        form = PatientSignupForm(request.POST)
        if form.is_valid():
            user = form.save()
            auth_login(request, user)
            messages.success(request, 'Login successful')
            return redirect('patient_dashboard')
    else:
        form = PatientSignupForm()
    return render(request, 'patient_signup.html', {'form': form})

def doctor_signup(request):
    if request.method == 'POST':
        form = DoctorSignupForm(request.POST)
        if form.is_valid():
            user = form.save()
            auth_login(request, user)
            messages.success(request, 'Login successful')
            return redirect('doctor_dashboard')
    else:
        form = DoctorSignupForm()
    return render(request, 'doctor_signup.html', {'form': form})
