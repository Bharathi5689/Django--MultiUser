# healthcare/urls.py
from django.urls import path
from django.contrib.auth.decorators import login_required
from django.contrib.auth.views import LogoutView
from .views import signup, patient_signup, doctor_signup, MyLoginView, dashboard_redirect, patient_dashboard, doctor_dashboard

urlpatterns = [
    path('signup/', signup, name='signup'),
    path('patient_signup/', patient_signup, name='patient_signup'),
    path('doctor_signup/', doctor_signup, name='doctor_signup'),
    path('patient_dashboard/', login_required(patient_dashboard), name='patient_dashboard'),
    path('doctor_dashboard/', login_required(doctor_dashboard), name='doctor_dashboard'),
    path('login/', MyLoginView.as_view(template_name='login.html'), name='login'),
    path('logout/', LogoutView.as_view(), name='logout'),
    path('dashboard/', login_required(dashboard_redirect), name='dashboard_redirect'),
]
